README.txt
For further assistance, please contact Ask Infineon
Germany: 0800 951 951 951 (German/English) 
China, Mainland: 4001 200 951 (Mandarin/English) 
USA: 1 866 951 9519 (English/German) 
India: 000 800 4402 951 (English) 
Direct Access: +49 89 234 65555 (German/English) 
International toll-free 0800 service 00** 800 951 951 951 
or email: Product-Services-Hotline@infineon.com

----------------------------------------------------------------------
Version 	Date			Changes / Remark
v1			2013-09-30		initial revision 